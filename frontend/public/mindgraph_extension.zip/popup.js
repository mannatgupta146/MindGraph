document.addEventListener('DOMContentLoaded', async () => {
    const siphonBtn = document.getElementById('siphon-btn');
    const initialState = document.getElementById('initial-state');
    const successState = document.getElementById('success-state');
    const siteTitle = document.getElementById('site-title');
    const siteUrl = document.getElementById('site-url');
    const siteIcon = document.getElementById('site-icon');
    const viewMemoryBtn = document.getElementById('view-memory');

    // Get current tab info
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab) {
            siteTitle.textContent = tab.title || 'Untitled Discovery';
            siteUrl.textContent = new URL(tab.url).hostname || 'Local Resource';
            siteIcon.textContent = (tab.title || '?').charAt(0).toUpperCase();
        }
    } catch (e) {
        console.error('Core Link Failure:', e);
        siteTitle.textContent = 'Development Environment';
        siteUrl.textContent = 'localhost';
    }

    siphonBtn.addEventListener('click', async () => {
        siphonBtn.disabled = true;
        const btnText = siphonBtn.querySelector('.btn-text');
        const btnLoader = siphonBtn.querySelector('.btn-loader');
        
        btnText.classList.add('hidden');
        btnLoader.classList.remove('hidden');

        // Simulate Neural Siphoning (OCR/Embedding/Linkage)
        setTimeout(() => {
            initialState.classList.add('hidden');
            successState.classList.remove('hidden');
            
            // In a real app, we'd send data to http://localhost:5000/api/saves
            console.log('SYSTEM: Neural Link established. Packet successfully siphoned to MindGraph core.');
        }, 2200);
    });

    viewMemoryBtn.addEventListener('click', () => {
        chrome.tabs.create({ url: 'http://localhost:5173/dashboard' });
    });
});
